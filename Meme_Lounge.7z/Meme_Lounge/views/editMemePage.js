import { html } from '../node_modules/lit-html/lit-html.js'
import { editMeme, getMemeById } from '../services/requests.js'

const editMemePageTemplate = (meme, onEditSubmitHandler) => html`
<section id="edit-meme">
    <form @submit=${onEditSubmitHandler} id="edit-form">
        <h1>Edit Meme</h1>
        <div class="container">
            <label for="title">Title</label>
            <input id="title" type="text" placeholder="Enter Title" name="title" .value=${meme.title}>
            <label for="description">Description</label>
            <textarea id="description" placeholder="Enter Description" name="description" .value=${meme.description}>
                </textarea>
            <label for="imageUrl">Image Url</label>
            <input id="imageUrl" type="text" placeholder="Enter Meme ImageUrl" name="imageUrl" .value=${meme.imageUrl}>
            <input type="submit" class="registerbtn button" value="Edit Meme">
        </div>
    </form>
</section>`

async function editMemePage(context) {
    const memeId = context.params.memeId; 
    const meme = await getMemeById(memeId);

    context.renderContent(editMemePageTemplate(meme, onEditMeme));

    async function onEditMeme(event) {
        event.preventDefault();

        try {
            const formData = new FormData(event.target);
            const [title, description, imageUrl] = [...formData.values()];

            if (!title || !description || !imageUrl) {
                throw new Error('All input fields are required!');
            }

            await editMeme(memeId, title, description, imageUrl);

            return context.page.redirect(`/details/${memeId}`);
        } catch (error) {
            alert(error.message);
        }
    }

}

export default editMemePage;