import { html } from '../node_modules/lit-html/lit-html.js';
import { login } from '../services/requests.js';

const loginPageTemplate = (onLoginiSubmitHandler) => html` 
    <section id="login">
        <form @submit=${onLoginiSubmitHandler} id="login-form">
            <div class="container">
                <h1>Login</h1>
                <label for="email">Email</label>
                <input id="email" placeholder="Enter Email" name="email" type="text">
                <label for="password">Password</label>
                <input id="password" type="password" placeholder="Enter Password" name="password">
                <input type="submit" class="registerbtn button" value="Login">
                <div class="container signin">
                    <p>Dont have an account?<a href="#">Sign up</a>.</p>
                </div>
            </div>
        </form>
    </section>`;


function loginPage(context) {
    context.renderContent(loginPageTemplate(onLogin));

    async function onLogin(event) {
        event.preventDefault();
        try {
            const formData = new FormData(event.target);
            const [email, password] = [...formData.values()];

            if (!email || !password) {
                throw new Error('All input fields are required!');
            }

            const userData = await login(email, password);

            sessionStorage.setItem('authToken', userData.accessToken);
            sessionStorage.setItem('email', userData.email);
            sessionStorage.setItem('userId', userData._id);
            sessionStorage.setItem('username', userData.username);

            context.setUserNav();
            context.page.redirect('/all-memes');
        } catch (error) {
            alert(error.message);
        }
    }
}

export default loginPage;