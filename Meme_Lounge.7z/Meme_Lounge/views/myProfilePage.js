import { html } from '../node_modules/lit-html/lit-html.js';
import { getMyMemes } from '../services/requests.js';

const myProfilePageTemplate = (memesCount, userMemes) => html`
<section id="user-profile-page" class="user-profile">
    <article class="user-info">
        <img id="user-avatar-url" alt="user-profile" src="/images/female.png">
        <div class="user-content">
            <p>Username: ${sessionStorage.getItem('username')}</p>
            <p>Email: ${sessionStorage.getItem('email')}</p>
            <p>My memes count: ${memesCount}</p>
        </div>
    </article>
    <h1 id="user-listings-title">User Memes</h1>
    <div class="user-meme-listings">
        <!-- Display : All created memes by this user (If any) -->
        ${
            userMemes.length > 0
            ? userMemes.map(meme => userMeme(meme))
            : html`<p class="no-memes">No memes in database.</p>`
        }
        <!-- Display : If user doesn't have own memes  -->
    </div>
</section>`

const userMeme = (userMeme) => html`
<div class="user-meme">
    <p class="user-meme-title">${userMeme.title}</p>
    <img class="userProfileImage" alt="meme-img" src=${userMeme.imageUrl}>
    <a class="button" href="/details/${userMeme._id}">Details</a>
</div>`;

async function myProfilePage(context) {
    const userId = sessionStorage.getItem('userId');
    const userMemes = await getMyMemes(userId);


    context.renderContent(myProfilePageTemplate(userMemes.length, userMemes)); 
}

export default myProfilePage;