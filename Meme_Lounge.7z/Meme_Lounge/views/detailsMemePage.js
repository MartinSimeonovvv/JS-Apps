import { html } from '../node_modules/lit-html/lit-html.js'
import { getMemeDetails, deleteMeme } from '../services/requests.js'

const detailsMemePageTemplate = (details, deleteMeme) => html`
<section id="meme-details">
    <h1>Meme Title: ${details.title}

    </h1>
    <div class="meme-details">
        <div class="meme-img">
            <img alt="meme-alt" src=${details.imageUrl}> 
        </div>
        <div class="meme-description">
            <h2>Meme Description</h2>
            <p>
                ${details.description}
            </p>
            <!-- Buttons Edit/Delete should be displayed only for creator of this meme  -->
            ${
                details._ownerId === sessionStorage.getItem('userId')
                ? html`<a class="button warning" href="/edit/${details._id}">Edit</a><button @click=${deleteMeme} class="button danger">Delete</button>`
                : null 
            }
        </div>
    </div>
</section>
`

async function detailsMemePage(context) {
    const memeId = context.params.memeId;
    const meme = await getMemeDetails(memeId);


    context.renderContent(detailsMemePageTemplate(meme, onDelete));

    async function onDelete() {
        if (confirm('Are u sure u want to delete that meme?!')) {
            await deleteMeme(memeId);
            return context.page.redirect('/all-memes');
        }
    }
}

export default detailsMemePage;