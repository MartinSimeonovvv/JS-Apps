import { html } from '../node_modules/lit-html/lit-html.js'
import { createMeme } from '../services/requests.js'

const createMemesPageTemplate = (meme) => html`
<section id="create-meme">
    <form @submit=${meme} id="create-form">
        <div class="container">
            <h1>Create Meme</h1>
            <label for="title">Title</label>
            <input id="title" type="text" placeholder="Enter Title" name="title">
            <label for="description">Description</label>
            <textarea id="description" placeholder="Enter Description" name="description"></textarea>
            <label for="imageUrl">Meme Image</label>
            <input id="imageUrl" type="text" placeholder="Enter meme ImageUrl" name="imageUrl">
            <input type="submit" class="registerbtn button" value="Create Meme">
        </div>
    </form>
</section>`

function createPage(context) {
    context.renderContent(createMemesPageTemplate(onCreateMeme));

    async function onCreateMeme(event) {
        event.preventDefault()

        try {
            const formData = new FormData(event.target);
            const [title, description, imageUrl] = [...formData.values()];

            if (!title || !description || !imageUrl) {
                throw new Error('All input fields are required!');
            }

            await createMeme(title, description, imageUrl);
            
            return context.page.redirect('/all-memes');
        } catch (error) {
            alert(error.message);
        }
    }
}

export default createPage;