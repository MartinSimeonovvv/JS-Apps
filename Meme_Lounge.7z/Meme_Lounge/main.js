import page from './node_modules/page/page.mjs';
import { render } from './node_modules/lit-html/lit-html.js';

// Import our page handlers
import homePage from '../views/homePage.js';
import allMemesPage from '../views/allMemesPage.js';
import registerPage from '../views/registerPage.js';
import loginPage from '../views/loginPage.js';
import createPage from '../views/createPage.js';
import myProfilePage from '../views/myProfilePage.js';
import editMemePage from '../views/editMemePage.js';
import detailsMemePage from '../views/detailsMemePage.js';

// Configurate the routing table
page('/', renderContentMiddleware, homePage);
page('/all-memes', renderContentMiddleware, allMemesPage);
page('/register', renderContentMiddleware, setUserNavMiddleware, registerPage);
page('/login', renderContentMiddleware, setUserNavMiddleware, loginPage);
page('/create', renderContentMiddleware, createPage);
page('/my-profile', renderContentMiddleware, myProfilePage);
page('/edit/:memeId', renderContentMiddleware, editMemePage);
page('/details/:memeId', renderContentMiddleware, detailsMemePage);

setUserNavigation();
// Start the router
page.start();

// Upload user status
function setUserNavigation() {
    if (sessionStorage.getItem('authToken') !== null) {
        document.querySelector('.user').style.display = 'block';
        document.querySelector('.guest').style.display = 'none';
        document.querySelector('.user span').textContent = `Welcome, ${sessionStorage.getItem('email')}`
    } else {
        document.querySelector('.user').style.display = 'none';
        document.querySelector('.guest').style.display = 'block';
    }
}

function renderContentMiddleware(context, next) {
    context.renderContent = (content) => render(content, document.querySelector('main'));

    next();
}

function setUserNavMiddleware(context, next) {
    context.setUserNav = setUserNavigation;

    next();
}

// Logout logic
document.getElementById('logoutBtn').addEventListener('click', () => {
    sessionStorage.clear();
    setUserNavigation();
    page.redirect('/');
});
