async function request(URL, options) {
    try {
        const response = await fetch(URL, options);

        if (response.ok === false) {
            const errorMessage = await response.json().message;
            throw new Error(errorMessage);
        }

        return await response.json();
    } catch (error) {
        alert(error.message);
    }
}

function setOptions(method, data = undefined) {
    let options = {
        method,
        headers: {}
    }

    if (data) {
        options.headers['Content-Type'] = 'application/json';
        options.body = JSON.stringify(data);
    }

    const authToken = sessionStorage.getItem('authToken');
    if (authToken) {
        options.headers['X-Authorization'] = authToken;
    }
    
    return options;
}

const host = 'http://localhost:3030'; 

async function get(endpoint) {
    return await request(host + endpoint, setOptions('get'));
}

async function post(endpoint, data) {
    return await request(host + endpoint, setOptions('post', data));
}

async function put(endpoint, data) {
    return await request(host + endpoint, setOptions('put', data));
}

async function del(endpoint) {
    return await request(host + endpoint, setOptions('delete'));
}

export {
    get,
    post,
    put,
    del
}