import { get, post, put, del } from '../services/api.js';

export async function register(username, email, password, gender) {
    return await post('/users/register', {
        username,
        email,
        password,
        gender
    }); 
}

export async function login(email, password) {
    return await post('/users/login', { email, password });
}

export async function createMeme(title, description, imageUrl) {
    return await post('/data/memes', { title, description, imageUrl });
}

export async function getAllMemes() {
    return await get('/data/memes?sortBy=_createdOn%20desc');
}

export async function getMemeDetails(id) {
    return await get('/data/memes/' + id);
}

export async function editMeme(id, title, description, imageUrl) {
    return await put('/data/memes/' + id, { title, description, imageUrl });
}

export async function deleteMeme(id) {
    return await del('/data/memes/' + id);
}

export async function getMyMemes(userId) {
    return await get(`/data/memes?where=_ownerId%3D%22${userId}%22&sortBy=_createdOn%20desc`);
}

export async function getMemeById(id) {
    return await get('/data/memes/' + id);
}